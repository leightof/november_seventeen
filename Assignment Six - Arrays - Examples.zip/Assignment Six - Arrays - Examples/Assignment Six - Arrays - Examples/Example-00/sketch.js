

function setup() {


var x = [12, 20]; //Declare and assign the array two values

print(x.length); // Prints 2 values to the console

var y = ["cat", 10, false, 50]; // Declare and assign the array

print(y.length); // Prints 4 to the console

var z = []; // Declare an empty arrary

print(z.length); // Prints 0 to the console

z[0] = 20;  // Assign an element to the array

print(z.length); // Prints 1 to the console

z[1] = 4; // Assign an element to the array

print(z.length); // Prints 2 to the console


}