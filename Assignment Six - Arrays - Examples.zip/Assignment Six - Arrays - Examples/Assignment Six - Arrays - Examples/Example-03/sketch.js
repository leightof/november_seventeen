
var x = []; // Declare the array

function setup() {

	createCanvas(240, 120);

	noStroke();

	fill(255, 200);

	for (var i = 0; i < 3000; i++) {

		//assign values to array based on for loop
		x[i] = random(-1000, 200); 

	}

}

function draw() {

	background(0);

	// use the length (number of values) of the array to determine when the for loop ends
	for (var i = 0; i < x.length; i++) {

		// use the stored value of the array and increment value, sets velocity on x-axis
		x[i] +=0.5;

		// use the i variable to determine y variable, sets position on y-axis
		var y = i * 0.4;

		// use the modified array value and the y value in this loop to draw an arc shape
		arc(x[i], y, 12, 12, 0.52, 5.76);
	}

}